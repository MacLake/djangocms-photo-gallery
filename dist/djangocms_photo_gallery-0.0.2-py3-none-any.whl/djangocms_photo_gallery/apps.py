from django.apps import AppConfig


class DjangocmsPhotoGalleryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'djangocms_photo_gallery'
    verbose_name = 'django CMS Photo Gallery'
